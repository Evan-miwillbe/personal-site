# 生成式AI搜索时代的TikTok视频搜索差异化战略

> 调研报告 | 投递附件：TikTok Search&AI 产品战略实习生
> 调研日期：2026-07-06 | 字数：约7800 | 来源：A+B级占80%+（3板块+QR核验）
> 方法：多Agent并行调研（3板块）+ 质量审查（QR三阶段+横向穿透）+ 独立Evaluator终裁
> 数据口径：经QR裁定（Google Q3 2025搜索收入采财报$56.57B；arXiv ViSIL论文研究视频字幕信息损失，引申为"视频护城河"标[推测]；2.0x purchase lift为TikTok官方厂商自报）

## 执行摘要

**核心判断**：生成式AI搜索（ChatGPT / Google AIO / Perplexity 三分格局）正在重塑搜索市场，但冲击的是可被AI无损压缩的文本信息。TikTok的视频搜索凭借多模态信息密度，构成AI摘要难以替代的"体验护城河"——AI能摘要视频"说了什么"，却无法摘要"展示了什么感觉"。TikTok占据的不是Google的份额，而是Google范式够不到的"体验发现"赛道，这是**范式分层而非零和竞争**。

但护城河不等于变现。第一性瓶颈在**信任**：TikTok算法优先engagement使UGC真实性受侵蚀，misinformation风险高于Google和小红书（KOC主动搜索信任）。**体验立根，信任定顶**——体验决定TikTok能否存在，信任决定能走多远。视频护城河是天赋，信任是需持续投入的工程。

**关键数据**：64% Gen Z用TikTok搜索（Rise at Seven）；68%美国Google搜索无点击（SparkToro 2026.06）；TikTok搜索广告2.0x购买提升（TikTok官方，厂商自报需打折）；TikTok Shop 2025全球GMV $64.3B / 美国$15.82B（eMarketer）；TikTok全球广告$32.4B，约为Google年搜索收入$226B的14-16%。

**3条战略建议**：
1. **信任基建（第一优先）**：扩展IAS第三方验证 + GARM品牌安全标准 + UGC真实性机制 + 创作者溯源，把"信任"从软肋变护城河
2. **AI Search体验设计**：视频原生搜索（多模态索引）+ 创作者溯源信任锚点 + 广告嵌入不破坏真实感，走Perplexity式"溯源换信任"与Google式"广告收口"之间的第三条路
3. **跨市场差异化**：美国（视频发现主导40-66%）/ 东南亚（直播主导70%）/ 欧洲（DSA合规）三套模板，不复制单一模式

---

## 一、范式判断：AI搜索三分格局与视频护城河

### 1.1 三分格局：三种范式分化

生成式AI搜索已分化为三条差异化路径，关键不在份额大小，而在范式分野：

- **ChatGPT（对话范式）**：流量份额52-68%（First Page Sage 2026.07），日查询约25亿，主攻会话式长链研究，"提问-回答"模式
- **Google AIO（整合范式）**：传统搜索仍占~90%，AI Overviews覆盖49% SERP（GrowByData 2025.06，SERP层面口径；查询层面触发率约20%+，口径不同需注明），Q3 2025搜索收入$56.57B（Alphabet财报），走"传统搜索+AI摘要"整合
- **Perplexity（溯源范式）**：$500M ARR（2026.04，The Information），流量份额2-4%，走"溯源引用+订阅"，已停广告

三者共同挤压了传统"蓝色链接"（Google十条蓝字结果）生态，但挤压的是文本信息检索。

### 1.2 zero-click冲击：精准打击可压缩文本

AI摘要的直接后果是zero-click（零点击）激增。SparkToro/Similarweb数据显示，2026年前4个月美国Google搜索**68.01%无点击**，欧洲59.7%，移动端75%（SparkToro 2026.06）。每1000次搜索仅360次点击外链（点击次数口径；与68.01%无点击的搜索次数口径不同，一次搜索可多次点击）。

更关键的是AIO对自然CTR的精准打击：AIO触发时自然CTR下降15-61%（平均18%），但**存活点击转化率提高23%**（digitalapplied 2026）。AI摘要不是消灭点击，而是"筛选"点击——信息类查询被摘要吞噬，交易类查询反而更精准。

**冲击的本质**：文本信息可被AI无损压缩进摘要，所以被压缩了。这恰是视频搜索护城河的起点。

### 1.3 视频护城河：为何视频天然抗AI摘要

> 核心论点（[推测]引申）：视频的多模态信息密度使其天然抗AI摘要，是TikTok最深的护城河。

arXiv（2026.01）ViSIL相关研究指出，视频是"密集、多维"的，AI摘要存在不可消除的"多模态信息损失"。需注明：原文研究视频字幕/Captioning信息损失度量，本报告将其[推测]引申为通用视频护城河论据。需进一步注明：论文亦发现视频摘要（Pareto最优前沿）比纯文本摘要VQA准确率仅高7%，暗示视频摘要虽有信息损失但并非完全不可行——护城河强度需审慎评估，信息损失≠商业不可替代性。原因有四：

1. **多层对齐脆弱性**：视频依赖视觉、听觉、时间、语言四层信息对齐，AI拆解重建时情感线索、弱对齐信号被当噪声过滤
2. **高密度与高冗余并存**：视频1秒内可塞入快速演变的视觉变化，AI难以在过滤冗余时保持时间连贯，常丢失跨帧关键细节
3. **"展示"而非"说出"**：视频大部分内容在肢体语言、表情、物理演示中，仅基于转录的AI摘要会遗漏视觉叙事与情感细微差别
4. **计算架构限制**：高分辨率视频需海量算力，AI常退化为评估孤立关键帧而非连续运动

这意味着：**AI能摘要视频"说了什么"，但无法摘要视频"展示了什么感觉"**。

文本搜索的危机在于信息可被无损压缩——一篇"最佳咖啡机"测评，AI能提取成5条要点。但一段咖啡机使用视频，其价值一半在信息（参数、价格），一半在体验（手感、声音、蒸汽大小、创作者的惊喜表情），后者无法被文字摘要传递。叠加创作者生态网络效应[推测]（真实体验样本不可被AI生成替代、不可被文本摘要吸收），构成AI无法压缩的壁垒；网络效应为定性判断，本报告无创作者留存/迁移数据支撑（见5.3节已知限制）。

### 1.4 范式分层：非零和竞争

TikTok占据的不是Google份额，而是Google范式够不到的赛道。Google的PageRank体系对"体验"无能为力——你无法用PageRank排序"这家餐厅的vibe"。TikTok的多模态索引（语音转录+屏幕OCR+字幕三信号对齐）+ 发现引擎恰好覆盖Google的结构性盲区。

Gen Z用脚投票验证了这一分层：64%用TikTok搜索、62%研究本地商家、77%做产品发现。他们用TikTok回答文本搜索回答不了的问题："这家餐厅什么氛围""这个产品用起来什么感觉"。

**判断**：文本搜索被压缩，视频搜索被需要。这是范式分层，不是零和竞争。[推测]Gen Z当前偏好支持范式分层判断，但行为偏好可迁移，不等于结构性护城河——需持续监测偏好回落信号（见5.2节Tubefilter）。

[推测]即使Google在搜索中集成视频AI摘要，也无法替代原生视频搜索，因为摘要本身就是在剥夺视频的体验性——用户要的是"看"，不是"被告诉看了什么"。

---

## 二、TikTok搜索现状：Gen Z行为与三层分化

### 2.1 Gen Z搜索行为：用脚投票的体验需求

Gen Z已把TikTok当主搜索引擎之一。Adobe 2026研究显示**65% Gen Z用过TikTok搜索**，WARC/TikTok联合研究发现**86%每周搜索**。场景分布（Adobe）：生活方式/爱好、美学美妆、娱乐、本地发现、产品发现五大类目。SOCi 2025年11月研究指出**62% Gen Z找本地商家时转向TikTok Places**；**77%用TikTok做产品发现**（Adobe/SQ Magazine），其中58%产品发现完全无计划（MomentIQ）。

内容偏好（Adobe）：视频教程61%、产品评测45%、个人故事41%、网红推荐仅33%——"真人用真实产品"压过"网红代言"。代际断崖明显：25% Gen Z认为TikTok找信息有效（vs 千禧17%、X世代12%、婴儿潮5%）。Sprout Social Q2 2025显示41% Gen Z首选社交媒体搜索，与Adobe"40%绕Google用社媒"口径吻合。

### 2.2 三层分化：TikTok在各赛道的占位

TikTok搜索竞争呈三层分化，底层变量是**用户意图**（pull研究 vs push娱乐）与**信任机制**（KOC背书 vs 算法engagement）：

**对Google：切走"主观体验/本地/产品"增量查询**。TikTok赢在"主观/体验/即时证明"查询（本地餐饮、美妆试色、穿搭灵感、how-to教程），Google赢在"客观/事实/导航"查询（新闻、导航、学术、事实核验）。Forbes 2024年3月：18-24岁中62%在TikTok搜索、Google为61%，几乎并驾齐驱但意图分轨。需注意Tubefilter的反转信号：近期Gen Z对TikTok偏好over Google有所回落，非单向替代——这可能是护城河弱化的早期征兆，需持续监测。

**对YouTube：输在意图深度与货架寿命**。YouTube月约140亿次搜索（仅次于Google，C级来源），Shorts承接高意图查询，背靠成熟SEO基础设施，**货架寿命长**——优质Short可在发布数周数月后被搜出。TikTok则是发现优先、病毒沉浸，美国用户日均约95分钟。YouTube=搜索导向的微答案+长尾积累，TikTok=算法推送的瞬时趋势+深度沉浸。这是pull/pull之分在视频内部的复现。

**对小红书：输在信任锚点与意图明确性**（跨市场参照，非同场竞争）。小红书月活3亿，月均搜索渗透率70-73%（千瓜/官方），90%搜索行为为主动发起（Sohu 2025-02，**注意：此"90%"指主动搜索行为占比，非信任度评分**；信任在小红书为定性"信任引擎"表述，无干净的90%信任调研值）。小红书pull（主动搜、收藏、对比验证）vs TikTok push（算法推送、被动滚动、冲动购买"TikTok Made Me Buy It"）。小红书靠素人KOC peer背书，TikTok靠潮流与网红社会证明。

### 2.3 信任软肋：视频搜索的隐藏天花板

信任是分化的隐藏轴。Talker Research提出"Netpicking"趋势：年轻用户不信精致企业内容，转而搜未剪辑视频、读评论区做peer评审。UGC被感知为"朋友建议"（NC State研究：TikTok真实性=原生未过滤，Instagram=美学故事讲述）。

但TikTok有结构性软肋：算法优先engagement与娱乐而非事实准确性，使TikTok比Google更易受misinformation影响（Terakeet，C级来源）。MDPI研究指出算法过滤模糊了有机可见性与赞助相关性的边界。

对冲上，**67% Gen Z需要数据/统计/真实洞察才敢信品牌**（Talker Research）——即用Google式事实核验来对冲TikTok的engagement偏差。小红书的信任优势由此凸显：主动搜索+KOC背书+图文可核验，构成"研究-验证-决策"闭环；TikTok的"被推送-种草-冲动"链路在低客单价冲动消费强，但在高决策成本类目（需比价、需测评、需长期信任）信任不足。这是TikTok搜索商业化的上限约束。

---

## 三、商业化：搜即买闭环与对标

### 3.1 搜索广告机制：关键词定向 × 视频原生格式

TikTok Search Ads Campaign（2024年9月24日美国上线）是关键词驱动的搜索结果页广告产品，机制三层：

1. **关键词定向**：广告主通过Keyword Suggestion Tool/手动录入/批量上传构建词表，支持Broad/Phrase/Exact三种匹配，每广告组最多1万个否定关键词控制品牌安全（TikTok官方）
2. **动态创意匹配**：AI自动选择与查询最相关的素材（视频/Spark Ad/Carousel）投放
3. **格式三件套**：视频广告（独立上传）、Spark Ads（推广品牌自有或授权创作者有机帖，保留有机互动数据，构建社交证明）、Carousel Image Ads（2-35张图片轮播）

Search Ads覆盖12个主要市场（美/加/英/德/法/意/西/墨/巴/沙特/澳/日），Lead Generation仅美国（TikTok官方2026-04）。本质是"视频原生+关键词意图"的杂交体——既保留Google式关键词竞价的高意图捕获，又通过视频格式实现Google文本广告做不到的"沉浸式说服"。

### 3.2 三大硬指标：独立商业化基础（含厂商自报caveat）

- **2.0x购买提升**：TikTok 2025年9月官方研究显示Search Ads相对无搜索campaign带来2.0x购买提升，企业零售子类1.9x（TikTok官方）。**需注明：此为TikTok厂商自报，B1/B2（Search Engine Land/Tulsa Marketing）仅转述非独立验证，引用需打折**
- **搜索+In-Feed协同+20%**：同时投放Search Ads与In-Feed Ads的广告主，整体转化较仅投Feed平均提升20%，成本持平或更低（TikTok官方，厂商自报）
- **18%二次转化**：18%看过In-Feed未转化的用户，在看到Search Ad后完成购买（Lane Agency）

行业基准对比：TikTok平均CPC $0.17-$1.50、转化率约1.2%；Google Search CPC $0.55-$150、转化率3.75%（Stackmatix/SQ Magazine）。Google转化率更高（高意图文本搜索），TikTok CPC更低（视频流量便宜）——两者分层互补而非直接替代。案例：Lunio AI报道某品牌Search Ads带来7.4万增量搜索曝光，转化率提升441%（C级案例）。

### 3.3 Shop电商化：搜即买闭环

TikTok Shop 2025全球GMV **$64.3B**（Branvas/Momentum Works），美国**$15.82B**（eMarketer，占美社交电商18.2%，53.2M买家）。增长动能：H1 2025美国GMV $5.8B（+91% YoY），Q3单季$19B（近eBay规模），eMarketer预测2026美国超$20B、2028超$30B。

驱动结构：**视频电商（in-feed短视频）占GMV 40-66%**，直播购物仅占美国GMV 10-30%——与中国抖音直播占70%形成鲜明对比（注：此为中国抖音数据；下文东南亚直播70%为不同市场的独立数据点）。美国市场是"视频发现"而非"直播带货"驱动。

搜索在电商化中扮演"意图收口"角色：用户经In-Feed短视频产生兴趣→主动搜索品牌/产品/评测→Search Ad在高意图时刻触达→完成转化。这形成"发现-搜索-购买"三角：**商品（Shop货架）× 内容（短视频发现）× 广告（搜索收口）** 协同，是Google/YouTube（缺内嵌电商货架）无法复制的结构。

### 3.4 对标：避开正面竞争，开辟体验驱动购买决策

| 平台 | 2025广告/交易规模 | 关键指标 |
|------|------------------|---------|
| Google Search & other | 年约$226B+（Q3 2025 $56.57B×4） | 每查询收入模型，AIO嵌广告25.56% SERP |
| YouTube ads | 年$40.37B | 视频发现+搜索混合，第二大Google广告源 |
| TikTok（全球广告） | $32.4-33.1B | 体验驱动购买决策，搜即买闭环 |
| TikTok（美国广告） | $12-14B（占全球41%） | — |
| TikTok Shop（GMV） | $64.3B（美国$15.82B） | 视频电商占40-66%，搜即买闭环载体 |

**关键洞察（口径需注明）**：TikTok广告收入（$32.4B）约为Google年搜索收入（$226B+）的**14-16%**，但TikTok Shop GMV（$64.3B，交易额口径）已超YouTube全年广告收入（$40.37B，平台收入口径）。注：GMV为交易额、广告收入为平台收入，口径不同不直接比较绝对值，但反映TikTok商业化重心在"搜索→电商GMV抽佣"的二级变现，而非Google式"每查询广告收入"。视频护城河（板块1）将搜索意图直接接驳即时消费，形成Google无法复制的"搜即买"闭环。

### 3.5 三重挑战

1. **信任与品牌安全**：搜索广告将品牌置于UGC旁，存在"广告邻接争议/未审核内容"风险。TikTok Inventory Filter三档（Expanded/Standard/Limited）对齐GARM标准；**IAS于2026年4月将媒体质量测量扩展至Search Ads Campaign**，提供第三方AI验证。但广告主对社交搜索环境的信任仍低于Google文本搜索。
2. **监管碎片化**：UK Online Safety Act 2023、欧盟数据安全、美国禁令不确定性构成跨市场合规负担。TikTok加入European Advertising Standards Alliance自监管，但误导广告/受限品类（医疗、金融）处罚严厉。
3. **跨市场差异**：印尼已超美国成TikTok Shop最大GMV市场，但东南亚直播电商主导（70%），美国视频发现主导（40-66%）——单一商业化模板无法全球复制。

[推测]TikTok搜索商业化天花板不取决于流量（已具备），而取决于三件事：信任基建能否拉齐Google、电商闭环深度能否从GMV增长中变现、监管稳定性。三者中任一恶化，2.0x purchase lift的存量优势难以持续转化为增量收入。视频护城河提供独立商业化基础，但护城河的"变现出口"仍是搜索广告+电商，需持续投入。

---

## 四、产品战略建议：信任基建为核心

> 战略主线（来自横向穿透第一性原理）：**体验立根，信任定顶**。视频护城河是天赋，信任是需持续投入的工程。第一性瓶颈在信任——它连接体验与商业化，是最脆弱、最可干预的变量。体验决定TikTok能否存在，信任决定能走多远；第一性壁垒在体验，第一性瓶颈在信任。

### 4.1 信任基建（第一优先）

信任是连接体验护城河与商业化的瓶颈，也是天花板。建议：

1. **第三方验证扩展**：IAS 2026-04已扩展至Search Ads，建议加速覆盖全Search Ads inventory + 引入更多第三方（DoubleVerify等），对标Google文本搜索的信任成熟度
2. **UGC真实性机制**：针对算法engagement优先致misinformation风险（Terakeet），建立"创作者身份验证+内容事实标注+高风险类目（健康/金融/法律）专家背书"三层机制。67% Gen Z需数据统计才信品牌（Talker Research），可设计"数据卡片"嵌入搜索结果
3. **创作者溯源信任锚点**：借鉴Perplexity"溯源换信任"路径，TikTok创作者溯源天然具备信任锚点。建议搜索结果页强化创作者权威标识（粉丝量/历史真实度/品类专长），让"真人用真实产品"可验证
4. **品牌安全GARM对齐**：Inventory Filter三档已有，建议细化Search Ads场景的邻接控制（避免品牌广告邻接争议UGC）

### 4.2 AI Search体验设计：第三条路

TikTok的AI Search不应照搬Google AIO（文本摘要）或Perplexity（溯源引用），而应走"视频原生+创作者溯源"的第三条路：

1. **视频原生AI摘要**：AI不替代视频，而是"导览"视频——生成视频关键片段索引（"这个测评在第15秒讲了价格"），用户仍看视频原片。保护体验性，不被摘要剥夺
2. **多模态索引深化**：TikTok已有语音转录+OCR+字幕三信号，建议扩展到视觉场景识别（产品/地点/动作），让"搜索咖啡机蒸汽大小"能定位到具体视频片段
3. **广告嵌入不破坏真实感**：Google路径证明"信息类查询可嵌广告"，但TikTok搜索是体验类，广告嵌入需更谨慎。建议Spark Ads优先（保留有机互动），Carousel次之，避免传统pre-roll打断体验
4. **创作者协同（Symphony）**：TikTok自家AI工具Symphony应与Search协同——创作者用Symphony生成内容时，自动优化搜索可发现性（关键词/标签/字幕），形成"创作-搜索-发现"闭环

### 4.3 跨市场差异化：三套模板

单一商业化模板无法全球复制（印尼超美国、东南亚直播主导70% vs 美国视频发现40-66%）。建议：

- **美国/欧洲**：视频发现驱动，Search Ads+Shop货架协同，重点突破高决策成本类目（需信任基建支撑）
- **东南亚**：直播电商主导，Search Ads与直播联动（直播切片可搜索），Shop GMV抽佣为主
- **欧洲**：DSA合规优先，AI Search需透明度（算法可解释+广告标识），信任基建与监管对齐

### 4.4 应对AI视频生成威胁（Sora/Veo）

QR横向穿透识别的关键盲区：AI视频生成可能让AI生成"伪体验视频"侵蚀创作者生态护城河。建议：

1. **真实体验锚点**：强化"真人真实体验"标识（地理位置/时间戳/购买凭证），区隔AI生成内容
2. **创作者身份验证**：C2PA内容凭证标准，搜索结果优先展示已验证创作者
3. **AI生成内容标注**：搜索结果明确标注AI生成视频，让用户区分真实体验与AI合成

### 4.5 短期/中期/长期建议

- **短期（0-3月）**：信任基建——IAS全Search Ads覆盖 + UGC真实性机制试点 + 创作者权威标识
- **中期（3-12月）**：AI Search体验——视频原生AI摘要（导览非替代）+ 多模态索引深化 + Symphony-Search协同
- **长期（1年+）**：跨市场差异化 + AI视频生成威胁应对（C2PA+真实体验锚点）+ 信任量化指标体系建立

---

## 五、跨市场差异、风险与已知限制

### 5.1 跨市场差异

TikTok搜索的全球化不能套用单一模板，三大市场结构迥异：

- **美国**：视频发现主导（占Shop GMV 40-66%），Search Ads 12国可用，Lead Gen仅美国。Gen Z搜索行为研究最丰富，是商业化主战场（广告$12-14B占全球41%）
- **东南亚**：直播电商主导（占GMV 70%），印尼已超美国成TikTok Shop最大GMV市场。搜索行为与直播切片联动，模式与美国分叉
- **欧洲**：DSA（数字服务法）+ UK OSA合规优先，AI Search需算法透明度+广告标识。信任基建与监管对齐是前置条件

### 5.2 风险caveat

1. **AI视频生成威胁（Sora/Veo）**：QR识别的最大潜在威胁——AI生成"伪体验视频"可能侵蚀创作者生态护城河。板块1"创作者生态网络效应"论点面临长期挑战
2. **Google反制**：Google若在搜索中集成视频AI摘要或YouTube Shorts搜索深化，板块1"范式分层"判断受挑战。Google已与TikTok早期测试（app内显示Google结果），既竞争又合作
3. **Gen Z偏好回落**：Tubefilter信号——近期Gen Z对TikTok偏好over Google有所回落，非单向替代，可能是护城河弱化早期征兆
4. **AIO扩展到视频**：SparkToro数据AIO使CTR降近60%，若AIO能力扩展到视频摘要，TikTok搜索也可能受冲击——板块1"视频抗摘要"判断的潜在反例
5. **美国禁令悬剑**：监管不确定性持续，2.0x purchase lift的存量优势难持续转化

### 5.3 已知限制

本研究存在以下限制，已在报告中标注：

1. **URL可定位性**：QR核验21个URL中0个能直接定位到具体数据来源页（8个404/000，11个根域名/目录/截断）。但9个抽查数据点全部真实，无编造数据/来源。核心数据点真实性已确认，可追溯性是短板
2. **TikTok搜索查询量缺位**：三板块均无TikTok日均/月均搜索量绝对值（Google 25亿/日、YouTube 140亿/月均有），无法量化商业化体量天花板
3. **抖音经验外推不足**：抖音（中国）作为TikTok前瞻参照，仅板块3提一句（直播70%），缺乏深度对比
4. **信任量化缺位**：三板块都谈信任，无统一度量（67%Gen Z需数据统计、小红书"信任引擎"定性、GARM标准），无统一信任指标体系
5. **厂商自报数据**：2.0x purchase lift、+20%转化为TikTok官方数据，无独立第三方验证，引用已打折
6. **arXiv论文引申**：ViSIL研究视频字幕/Captioning信息损失，"视频护城河"为[推测]引申，概念跳跃已标注；论文亦发现视频摘要比文本VQA仅高7%，护城河强度需审慎评估
7. **创作者生态网络效应**：板块1"网络效应飞轮"为定性判断，无创作者留存/迁移数据支撑

---

## 六、结论

生成式AI搜索的冲击是真实的——68% zero-click、CTR降15-61%——但冲击的是可被摘要的文本信息。视频搜索的多模态信息密度、体验不可压缩性、创作者生态网络效应，使其成为AI摘要时代的范式避风港。

TikTok占据的不是Google的份额，而是Google范式够不到的"体验发现"赛道。这不是"谁赢"的问题，而是**范式分层**的判断：文本搜索被压缩，视频搜索被需要。

但护城河不等于变现。**体验立根，信任定顶**——体验（多模态不可压缩）是TikTok区别于Google的根本，是"能否存在"的根；信任（UGC真实性）是体验能否转化为决策的瓶颈，是"能走多远"的顶。第一性壁垒在体验（难复制），第一性瓶颈在信任（脆弱且可侵蚀）。

TikTok搜索的战略，应围绕"信任基建"展开：把算法engagement优先导致的信任软肋，通过第三方验证、UGC真实性机制、创作者溯源、GARM品牌安全，转化为可验证的信任锚点。视频护城河是天赋，信任是需持续投入的工程——这恰恰是Search&AI产品战略团队最该解决的问题。

---

## 参考文献（按板块分组）

### 板块1：范式与护城河
- [A] arXiv (2026.01) ViSIL: Unified Evaluation of Information Loss in Multimodal Video Captioning | https://arxiv.org/abs/2601.09851
- [A] SparkToro/Similarweb (2026.06) zero-click 68.01% | https://sparktoro.com/blog/in-2026-less
- [A] The Information Perplexity $500M ARR | https://www.theinformation.com/briefings
- [A] Google Help AIO广告放置规则 | https://support.google.com/answer
- [B] First Page Sage (2026.07) ChatGPT 52-68%份额 | https://firstpagesage.com
- [B] GrowByData (2025.06) AIO覆盖49% SERP | https://growbydata.com
- [B] Semrush (2026.02) AIO广告25.56% | https://www.semrush.com/blog
- [B] digitalapplied CTR降15-61% | https://www.digitalapplied.com/blog
- [B] Rise at Seven (2024.12) 64% Gen Z用TikTok搜索 | https://riseatseven.com
- [B] SOCi (2025.05) 62% Gen Z本地商家 | https://www.soci.ai/blog

### 板块2：用户与竞争
- [A] Adobe Gen Z搜索行为 65%/77% | https://www.adobe.com/learn/blog
- [A] Sprout Social Q2 2025 41%首选社媒搜 | https://www.sproutsocial.com
- [A] NC State University UGC真实性 | https://www.ncsu.edu
- [A] 千瓜/小红书官方 月活3亿/70%渗透 | https://www.qian-gua.com
- [B] WARC/TikTok 86%每周搜 | https://www.warc.com
- [B] Forbes (2024-03) 62% TikTok vs 61% Google | https://www.forbes.com
- [B] Talker Research 67%需数据统计 | https://www.talkerresearch.com
- [B] Sohu (2025-02) 小红书90%主动搜索 | https://www.sohu.com
- [C] Terakeet TikTok misinformation脆弱性 | https://www.terakeet.com
- [C] digitalapplied YouTube 140亿月搜 | https://www.digitalapplied.com

### 板块3：商业化
- [A] TikTok官方 About Search Ads Campaign (2025-07) | https://ads.tiktok.com/help/article/about-search-ads-campaign
- [A] TikTok官方 Unlocking Incremental Growth (2025-09) 2x purchase lift | https://ads.tiktok.com/business/blog
- [A] TikTok官方 Search Ads Availability (2026-04) 12市场 | https://ads.tiktok.com/help/article
- [A] Alphabet Q3 2025 Earnings Google Search $56.57B | https://s206.q4cdn.com/doc_financials/2025
- [A] Alphabet Q4/FY2025 YouTube $40.37B | https://s206.q4cdn.com/doc_financials/2025
- [A] IAS (2026-04) 扩展Search Ads测量 | https://integralads.com/news
- [B] eMarketer (2025-12) Shop美国$15.82B/18.2% | https://www.emarketer.com/press-releases
- [B] Marketing Dive (2025-03) TikTok全球广告$32.4B | https://www.marketingdive.com
- [B] Search Engine Land (2025-09) 2x purchase lift转述 | https://searchengineland.com
- [B] Statista (2026-06) 印尼超美国 | https://www.statista.com/topics/e-commerce
- [B] Retail Dive (2025-12) 2026超$20B | https://www.retaildive.com
- [C] Social Commerce Club 美国GMV $13.2B(差异值) | -

> 完整URL与数据点验证状态见各板块 data/sources_registry.md + 08_质量控制/fact-check-log.md
> 本报告经独立Evaluator 5维终裁（来源覆盖/反驳完整/数据时效/因果链/内部一致），PASS≥70交付。
